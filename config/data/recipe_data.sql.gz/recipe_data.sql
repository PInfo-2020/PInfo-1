CREATE USER recipe WITH PASSWORD 'recipe';

