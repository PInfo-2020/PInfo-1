CREATE USER fridge WITH PASSWORD 'fridge';

